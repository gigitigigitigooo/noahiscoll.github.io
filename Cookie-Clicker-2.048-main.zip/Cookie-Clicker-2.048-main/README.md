# Cookie Clicker Downloadable HTML
2.048 source code for educational purposes. <br>
Download and extract from the "Releases" section.<br>
Or use the <a target="_blank" href="https://sushi8756.github.io/Cookie-Clicker-2.048/">website</a>!<br><br>
Website version loads a bit faster, but can get blocked.<br>
Downloadable HTML version loads a bit slower, but cannot get blocked.<br><br>
Lucky you! I actually updated this to a version after 2.048! But will I keep doing it?<br>
Credits go Orteil, visit the official website here: http://orteil.dashnet.org/cookieclicker/
<br><br><br>
The missing textures should also be back.<br>(Remember, any issues you have please tell me in the issues tab!)
